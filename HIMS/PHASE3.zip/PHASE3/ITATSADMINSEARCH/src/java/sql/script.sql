drop database if exists db_itats;
create database  db_itats;
use  db_itats;

create table tbl_transporation(
`id` int(11) primary key auto_increment,
`city` varchar(30),
`state`  varchar(30),
`country`  varchar(30),
`minFare`  varchar(5),
`maxFare`  varchar(5),
 `active` int(1)
);

create table tbl_hotel(
`id` int(11) primary key auto_increment,
`city` varchar(30),
`state`  varchar(30),
`country`  varchar(30),
`minFare`  varchar(5),
`maxFare`  varchar(5),
 `active` int(1)
);

create table tbl_food(
`id` int(11) primary key auto_increment,
`city` varchar(30),
`state`  varchar(30),
`country`  varchar(30),
`minFare`  varchar(5),
`maxFare`  varchar(5),
 `active` int(1)
);

create table tbl_tour(
`id` int(11) primary key auto_increment,
`city` varchar(30),
`state`  varchar(30),
`country`  varchar(30),
`minFare`  varchar(5),
`maxFare`  varchar(5),
 `active` int(1)
);