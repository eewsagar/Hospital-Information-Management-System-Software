package com.main.ext.services;

interface IEmailConstant {

    String USER_NAME = "testprojectauthentication@gmail.com";
    String PASSWORD = "123456789@a";
    String EMAIL_SUBJECT = "Hello world";
}
