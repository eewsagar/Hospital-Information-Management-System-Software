package com.main.ext.services;

import java.util.Random;

public class TemplateService {

    public static void main(String[] args) {
        String saltString = new TemplateService().getRandomString();
    }

    public String getEmailTemplate() {
        String emailTemplate = "Email Template thak your for the registration";
        return emailTemplate;
    }

    public String getAuthenticationTemplate(String userName) {
        String emailTemplate = "Authentication Template";
        return emailTemplate;
    }

    public String getPromotionTemplate() {
        String emailTemplate = "";
        return emailTemplate;
    }

    public String getSMSTemplate() {
        String emailTemplate = "";
        return emailTemplate;
    }

    protected String getRandomString() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 18) {
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        return saltStr;
    }
}
