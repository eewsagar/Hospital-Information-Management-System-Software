package com.main.servlet;

import com.main.refector.SingoltonConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.ResultSet;

@WebServlet(name = "RegistrationServlet", urlPatterns = {"/RegistrationServlet"})
public class RegistrationServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            String txtFullName = request.getParameter("txtFullName");
            String txtMobileNumber = request.getParameter("txtMobileNumber");
            String txtEmailId = request.getParameter("txtEmailId");
            String txtPassword = request.getParameter("txtPassword");
            
            if (checkUserName(txtEmailId) == 0) {
                String query
                        = "INSERT INTO `tbl_registration` (`id`, `txtUserType`, `txtFirstName`, "
                        + "`txtMobileNumber`, `txtEmailId`, `txtUserName`,"
                        + "`txtPassword`, `txtEntryDate`, `txtIsActive"
                        + "`) VALUES"
                        + "(NULL, 'd', '"+txtFullName+"', '"+txtMobileNumber+"',"
                        + "'"+txtEmailId+"', '"+txtEmailId+"',"
                        + "'"+txtPassword+"', NULL"
                        + ", 'Y');";

                SingoltonConnection.makePreparedStatement(query).execute();
                request.getSession().setAttribute("fullname", txtFullName);
                request.getSession().setAttribute("username", txtEmailId);
                response.sendRedirect("admin/mainpage.jsp?page=home");

                //String emailTemplate = new TemplateService().getEmailTemplate();
                //new SendEmailServices(emailTemplate, txtEmailId);
            } else {
                response.sendRedirect("admin/index.jsp?error=error");
            }
        } catch (Exception ex) {
            Logger.getLogger(RegistrationServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private int checkUserName(String userName) {
        int loginId = 0;
        try {
            String query = "select id from tbl_registration where txtUserName= '" + userName + "' ";
            ResultSet executeQuery = SingoltonConnection.makePreparedStatement(query).executeQuery();

            while (executeQuery.next()) {
                loginId = executeQuery.getInt("id");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return loginId;
    }

}
