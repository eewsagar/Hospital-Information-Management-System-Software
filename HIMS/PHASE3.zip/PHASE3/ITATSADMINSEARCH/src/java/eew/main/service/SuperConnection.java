package eew.main.service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import org.hibernate.HibernateException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class SuperConnection {

    public static Session session = null;
    public static Transaction transaction = null;
    private static  SessionFactory sessionFactory;

//    public static boolean checkStatus() {
//        try {
//            if (session == null) {
//                return false;
//            }
//            return true;
//        } catch (Exception e) {
//            return false;
//        }
//    }
    
    

    static {
        try {
            // Create the SessionFactory from standard (hibernate.cfg.xml) 
            // config file.
            
            Configuration configuration = new Configuration().configure();
            ServiceRegistry serviceRegistry
                = new StandardServiceRegistryBuilder()
                    .applySettings(configuration.getProperties()).build();
             
            // builds a session factory from the service registry
            sessionFactory = configuration.buildSessionFactory(serviceRegistry); 
            
        } catch (HibernateException ex) {
            // Log the exception. 
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static void saveEntity(Object entity) throws Exception {
        session = getSessionFactory().getCurrentSession();
        transaction = session.beginTransaction();
        session.save(entity);
        transaction.commit();
        session.close();
    }

    public static void updateEntity(Object entity) throws Exception {
        session = getSessionFactory().getCurrentSession();
        transaction = session.beginTransaction();
        session.update(entity);
        transaction.commit();
        session.close();
    }

    public static void deleteEntity(Object entity) throws Exception {
        session = getSessionFactory().getCurrentSession();
        transaction = session.beginTransaction();
        session.delete(entity);
        transaction.commit();
        session.close();
    }

//    public static <T> List<T> listEntity(T entity) throws Exception {
//        session = getSessionFactory().getCurrentSession();
//        transaction = session.beginTransaction();
//        //Criteria criteria = session.createCriteria(entity.getClass());
//
//// Create CriteriaQuery
//        CriteriaQuery criteria;
//        criteria = session..createQuery(entity.getClass());
//         return criteria.getGroupList();
//        
//    }

    public static List<Object> listEntityByQuery(String query) throws Exception {
        session = getSessionFactory().getCurrentSession();
        transaction = session.beginTransaction();
        List<Object> result = session.createQuery(query).list();
        return result;
    }

    public static Object uniqueRecordByQuery(String query) throws Exception {
        session = getSessionFactory().getCurrentSession();
        transaction = session.getTransaction();
        List<Object> result = session.createQuery(query).list();
        
        return result.toString();
    }

    public static String getMd5String() {
        String md5 = "" + new Date().getTime();
        StringBuilder sb = new StringBuilder();
        try {
            MessageDigest instance = MessageDigest.getInstance("MD5");
            instance.update(md5.getBytes());
            byte[] digest = instance.digest();
            for (int index = 0; index < digest.length; index++) {
                sb.append(Integer.toString((digest[index] & 0xff) + 0x100, 16).substring(1));
            }
        } catch (NoSuchAlgorithmException e) {
        }
        return sb.toString();
    }
    
}
