
import com.main.pojo.Dataentry;
import com.main.pojo.Datasearch;
import eew.main.service.SuperConnection;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author yuvraj
 */
public class TestMe {

    private static Object checkUserName(String userName) {
        try {
            Dataentry datasearch = new Dataentry();
            datasearch.setCategory("1");
            datasearch.setType("1");
            datasearch.setNmae("1");
            datasearch.setCity("1");
            datasearch.setAddress("1");
            datasearch.setCharge("1");
            SuperConnection.saveEntity(datasearch);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void main(String[] args) {
        checkUserName("pravint@gmail.com");
    }

}
